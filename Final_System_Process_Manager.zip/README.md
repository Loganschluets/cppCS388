# cppCS388

run using commands: 
run once:
chmod +x run.sh

run every time after:
./run.sh

