
#ifndef CONSTANTS_HPP
#define CONSTANTS_HPP

#include <string>

namespace Constants {
    const std::string WELCOME_MESSAGE = "Welcome to the System Process Manager!\n";
    const std::string TERMINAL_PROMPT = "[SPM]$ ";
    const std::string EXIT_COMMAND = "exit";
}

#endif
