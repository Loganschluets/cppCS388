
#include <iostream>
#include <string>
#include <sstream>
#include <vector>
#include <cstdlib>
#include <fstream>
#include "constants.hpp"

using namespace std;

void showProcesses();
void killProcess(const string& pid);
void showMemoryInfo();
void showNetworkInfo();
void logAction(const string& action);

int main() {
    cout << Constants::WELCOME_MESSAGE;
    string line;

    while (true) {
        cout << Constants::TERMINAL_PROMPT;
        getline(cin, line);
        istringstream iss(line);
        string command;
        iss >> command;

        if (command == "exit") break;
        else if (command == "processes") showProcesses();
        else if (command == "kill") {
            string pid;
            iss >> pid;
            if (!pid.empty()) killProcess(pid);
            else cout << "Usage: kill <pid>\n";
        }
        else if (command == "memory") showMemoryInfo();
        else if (command == "network") showNetworkInfo();
        else cout << "Unknown command: " << command << "\n";
    }

    return 0;
}

void showProcesses() {
    system("ps -eo pid,ppid,cmd,%mem,%cpu --sort=-%mem");
    logAction("Displayed processes");
}

void killProcess(const string& pid) {
    string cmd = "kill -9 " + pid;
    int status = system(cmd.c_str());
    if (status == 0) cout << "Process " << pid << " killed successfully.\n";
    else cout << "Failed to kill process " << pid << ".\n";
    logAction("Killed process: " + pid);
}

void showMemoryInfo() {
    cout << "\n[System Memory Usage]\n";
    system("free -h");

    cout << "\n[Top 5 Memory-Using Processes]\n";
    system("ps -eo pid,cmd,%mem --sort=-%mem | head -n 6");

    logAction("Displayed memory info");
}

void showNetworkInfo() {
    cout << "\n[Active TCP/UDP Connections]\n";
    system("ss -tunap");

    logAction("Displayed network info");
}

void logAction(const string& action) {
    ofstream logfile("spm_log.txt", ios::app);
    if (logfile.is_open()) {
        logfile << "[LOG] " << action << "\n";
        logfile.close();
    }
}
