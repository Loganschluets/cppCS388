#!/bin/bash

OUTPUT="main"

g++ *.cpp -o $OUTPUT

./$OUTPUT